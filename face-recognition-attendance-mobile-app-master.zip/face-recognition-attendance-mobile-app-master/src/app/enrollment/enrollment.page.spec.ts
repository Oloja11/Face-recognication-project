import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { EnrollmentPage } from './enrollment.page';

describe('EnrollmentPage', () => {
  let component: EnrollmentPage;
  let fixture: ComponentFixture<EnrollmentPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EnrollmentPage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(EnrollmentPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
