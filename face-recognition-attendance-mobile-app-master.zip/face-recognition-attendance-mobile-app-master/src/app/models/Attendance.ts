import { Student } from './Student';

export class Attendance {
    entryTime:Date;
    exitTime:Date;
    student:Student;
}