export class Image {
    id:string;
    data:string;
}