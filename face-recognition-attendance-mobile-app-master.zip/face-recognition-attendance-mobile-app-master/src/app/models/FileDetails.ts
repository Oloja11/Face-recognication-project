export class FileDetails {
    id: number
    name: string;
    link: string;
    type: string;
    mime: string;
}