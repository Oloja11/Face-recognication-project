export class Student {
    personId:string;
    regNo: string;
    fullName: string;
    email: string;
    phone: string
}